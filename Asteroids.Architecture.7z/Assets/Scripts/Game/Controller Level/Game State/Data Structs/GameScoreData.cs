using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct GameScoreData
{
    public int score;
    public int wave;
}
