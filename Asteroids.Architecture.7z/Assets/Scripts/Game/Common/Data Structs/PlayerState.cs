using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct PlayerState
{
    public Vector2 position;
    public Vector2 speed;

    public Vector2 direction;
}
