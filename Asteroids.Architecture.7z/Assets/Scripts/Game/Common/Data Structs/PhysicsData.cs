[System.Serializable]
public struct PhysicsData
{
    public float dragValue;
    public float dragSpeedMultiplier;
}