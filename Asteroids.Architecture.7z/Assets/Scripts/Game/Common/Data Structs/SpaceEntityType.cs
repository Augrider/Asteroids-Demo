using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum SpaceEntityType
{
    Player,
    Enemy,
    Projectile
}
