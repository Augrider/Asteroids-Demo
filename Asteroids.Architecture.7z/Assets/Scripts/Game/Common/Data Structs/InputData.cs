using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct InputData
{
    public float acceleration;
    public float rotation;

    public bool shootPrimary;
    public bool shootSpecial;
}
